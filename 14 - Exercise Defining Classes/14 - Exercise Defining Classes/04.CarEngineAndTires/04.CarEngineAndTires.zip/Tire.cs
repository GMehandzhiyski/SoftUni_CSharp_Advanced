﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.CarEngineAndTires
{
    public class Tire
    {
		private int Year;
		private double pressure;

        public Tire(int year, double pressure)
        {
				Year = year;
				Pressure = pressure;
        }

        public int year
		{
			get { return year; }
			set { year = value; }
		}
		public double Pressure
		{
			get { return pressure; }
			set { pressure = value; }
		}

	}
}
