﻿using System;

namespace _04.CarEngineAndTires
    public class StartUp
    {
        static void Main()
        {
            //Car car = new();
            //car.Make = "Vw";
            //car.Model = "Golf";
            //car.Year = 2025;
            //car.FuelQuantity = 200;
            //car.FuelConsumption = 10;
            //car.Drive(2000);

            //string make = Console.ReadLine();
            //string model = Console.ReadLine();
            //int year = int.Parse(Console.ReadLine());
            //double fuelQuantity = double.Parse(Console.ReadLine());
            //double fuelConsumption = double.Parse(Console.ReadLine());

            //Car firstCar = new Car();
            //Car secondCar = new Car(make, model, year);
            //Car thirdCar = new Car(make, model, year, fuelQuantity, fuelConsumption);

            Tire[] tires =
            {
                new Tire(1, 2.5),
                new Tire(1, 2.1),
                new Tire(2, 0.5),
                new Tire(2, 2.3),
             };

            Engine engine = new(560, 6.300);
            Car car = new("Lamborghini", "Urus", 2010, 250, 9, engine, tires);

            Console.WriteLine(car.WhoAmI());

        }

        
    }
}
